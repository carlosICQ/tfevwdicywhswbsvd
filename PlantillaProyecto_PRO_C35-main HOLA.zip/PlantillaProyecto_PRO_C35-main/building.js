
class Building{
    
}